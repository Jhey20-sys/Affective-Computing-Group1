%pip install librosa scikit-learn scipy matplotlib pillow torch torchvision seaborn pandas numpy
