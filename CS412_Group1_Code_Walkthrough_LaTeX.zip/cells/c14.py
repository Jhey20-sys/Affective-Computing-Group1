key_feats = ["f0_mean", "f0_std", "rms_mean", "zcr_mean", "duration", "active_ratio"]

for target in ["valence_class", "arousal_class"]:
    d = feat_df[key_feats].copy()
    d[target] = df[target].values
    classes = sorted(d[target].unique())
    rows = []
    for feat in key_feats:
        a = d.loc[d[target] == classes[0], feat].values
        b = d.loc[d[target] == classes[1], feat].values
        row = {"feature": feat}
        for c in classes:
            row[f"{c} median"] = round(d.loc[d[target] == c, feat].median(), 3)
        for c in classes:
            vals = d.loc[d[target] == c, feat]
            row[f"{c} mean (sd)"] = f"{vals.mean():.3f} ({vals.std():.3f})"
        row["p (uncorrected)"] = round(mannwhitneyu(a, b).pvalue, 3)
        rows.append(row)
    tbl = pd.DataFrame(rows)
    print("\n" + target, d[target].value_counts().to_dict())
    display(tbl)
    tbl.to_csv(out_dir / f"rq3_{target}_acoustic_comparison.csv", index=False, encoding="utf-8")

    fig, ax = plt.subplots(1, len(key_feats), figsize=(16, 3.4))
    for a, feat in zip(ax, key_feats):
        sns.boxplot(data=d, x=target, y=feat, ax=a, color="lightgray")
        sns.stripplot(data=d, x=target, y=feat, ax=a, color="black", size=4)
        a.set_xlabel("")
        a.set_title(feat, fontsize=9)
    fig.suptitle(f"Acoustic features by {target.replace('_', ' ')} (each dot = one recording)", fontsize=11)
    plt.tight_layout()
    save_fig(fig, f"rq3_{target}_acoustic_boxplots")
    plt.show()
