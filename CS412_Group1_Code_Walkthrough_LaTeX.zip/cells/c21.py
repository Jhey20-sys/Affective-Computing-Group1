no_libog = (df["word"] != "Libog").values
df2 = df[no_libog].reset_index(drop=True)
folds2 = list(LeaveOneGroupOut().split(df2, groups=df2["participant"]))

rows = []
for target in TARGETS:
    config = best_cfg[target]
    X2 = feature_sets[config["features"]][no_libog]
    y2 = df2[target].values
    p = cross_val_predict(make_model(config["model"]), X2, y2, cv=folds2)
    base = cross_val_predict(DummyClassifier(strategy="most_frequent"), np.zeros((len(y2), 1)), y2, cv=folds2)
    correct, base_acc = int((p == y2).sum()), accuracy_score(y2, base)
    full = results[target].query("features == @config['features'] and model == @config['model']").iloc[0]
    rows.append({"target": target, "configuration": f"{config['features']} ({config['model']})",
                 "all 30: accuracy": full["accuracy"], "all 30: macro-F1": full["macro_f1"],
                 "without Libog: correct": f"{correct}/{len(y2)}", "without Libog: accuracy": round(correct / len(y2), 3),
                 "without Libog: macro-F1": round(f1_score(y2, p, average="macro"), 3),
                 "without Libog: baseline accuracy": round(base_acc, 3),
                 "without Libog: binomial p": round(binomtest(correct, len(y2), base_acc, alternative="greater").pvalue, 3)})
no_libog_results = pd.DataFrame(rows)
no_libog_results.to_csv(out_dir / "sensitivity_without_libog.csv", index=False)
display(no_libog_results.T)
