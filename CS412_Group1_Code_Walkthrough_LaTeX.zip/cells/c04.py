meta = pd.read_csv(meta_csv)
df = meta.rename(columns={"Audio Filename": "file", "Valence": "valence", "Arousal": "arousal"}).copy()
df["participant"] = df["file"].str.split("_").str[0]
df["word"] = df["file"].str.replace(".wav", "", regex=False).str.split("_").str[-1]
df["path"] = [str(audio_dir / f) for f in df["file"]]

# 4-5 -> positive / high, 1-3 -> non-positive / low-mod
df["valence_class"] = np.where(df["valence"] > 3, "positive", "non-positive")
df["arousal_class"] = np.where(df["arousal"] > 3, "high", "low-mod")

missing = [p for p in df["path"] if not Path(p).exists()]
print("missing audio:", missing)
df = df[~df["path"].isin(missing)].reset_index(drop=True)
meta_by_file = meta.set_index("Audio Filename")

print(len(df), "recordings from", df["participant"].nunique(), "participants")
print(df["valence_class"].value_counts().to_dict())
print(df["arousal_class"].value_counts().to_dict())
print(df["word"].value_counts().to_dict())
