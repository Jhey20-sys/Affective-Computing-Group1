for col in ["Year Level", "Class Activity", "Session"]:
    df[col] = df["file"].map(meta_by_file[col])

summary = df[["valence", "arousal"]].describe().round(2)
display(summary)
summary.to_csv(out_dir / "exploratory_rating_summary.csv")

fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
sns.countplot(x="valence", data=df, order=[1, 2, 3, 4, 5], ax=ax[0])
sns.countplot(x="arousal", data=df, order=[1, 2, 3, 4, 5], ax=ax[1])
ax[0].set_title("Valence ratings")
ax[1].set_title("Arousal ratings")
plt.tight_layout()
save_fig(fig, "exploratory_rating_distribution")
plt.show()

for col in ["Year Level", "Class Activity", "Session", "word"]:
    name = col.lower().replace(" ", "_")
    tbl = df.groupby(col)[["valence", "arousal"]].agg(["count", "mean", "std"]).round(2)
    print("\n" + col)
    display(tbl)
    tbl.to_csv(out_dir / f"exploratory_{name}_summary.csv")
    if df[col].nunique() < 2:
        print("only one value, nothing to compare")
        continue
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.5))
    for a, v in zip(ax, ["valence", "arousal"]):
        sns.stripplot(data=df, x=col, y=v, ax=a, jitter=True, size=8)
        a.set_ylim(0.5, 5.5)
        a.set_title(f"{v.capitalize()} by {col}")
        a.tick_params(axis="x", rotation=30)
    plt.tight_layout()
    save_fig(fig, f"exploratory_{name}")
    plt.show()

word_by_activity = pd.crosstab(df["Class Activity"], df["word"])
print("\nword x activity")
display(word_by_activity)
word_by_activity.to_csv(out_dir / "exploratory_word_by_activity_counts.csv")
