audio_dir = Path("audio")
video_dir = Path("video")
meta_csv = Path("GROUP 1_Metadata.csv")

out_dir = Path("RESULTSV3")
spec_dir = out_dir / "SPECTROGRAMS"                   # plain images for the CNN
spec_labelled_dir = out_dir / "spectrograms_labelled"  # same images with axes, for the report
data_dir = out_dir / "datasets"
for folder in [out_dir, spec_dir, spec_labelled_dir, data_dir]:
    folder.mkdir(parents=True, exist_ok=True)

SR = 16000
CLIP_SEC = 1.5    # spectrogram images are padded/cut to 1.5 s
N_MELS = 128
IMG_SIZE = 224

N_PCA = 5         # small because we only have 30 people
N_PERM = 1000

MIN_VALID = 40
GROUP_YEAR = "1st Year"
WORDS = ["Salamat", "Ambot", "Grabe", "Lisod", "Sayon", "Lingaw", "Kapoy", "Libog"]  # we added Libog (confused)

# fill these in before submitting
session_cutoff = "TO FILL IN: the cutoff agreed before collection (e.g. Morning = classes ending before 12:00 PM)"
missing_reason = "TO FILL IN: reason participant numbers 003, 005, 007 are missing"


def save_fig(fig, name):
    fig.savefig(out_dir / f"{name}.png", dpi=300, bbox_inches="tight")
