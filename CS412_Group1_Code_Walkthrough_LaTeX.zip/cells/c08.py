df["feeling"] = df["file"].map(meta_by_file["Self-Reported Feeling"]).astype(str).str.strip().str.lower()
feelings = df["feeling"].value_counts().to_frame("count")
display(feelings)
feelings.to_csv(out_dir / "rq1_self_reported_feelings_counts.csv", encoding="utf-8")

class_counts = pd.crosstab(df["valence_class"], df["arousal_class"])
display(class_counts)
class_counts.to_csv(out_dir / "rq1_valence_class_by_arousal_class_counts.csv", encoding="utf-8")

# small random jitter so points with the same rating don't sit on top of each other
jitter = np.random.default_rng(SEED)
fig = plt.figure(figsize=(5.5, 5))
sns.scatterplot(x=df["valence"] + jitter.uniform(-0.12, 0.12, len(df)),
                y=df["arousal"] + jitter.uniform(-0.12, 0.12, len(df)),
                hue=df["word"], s=110, alpha=0.8)
plt.xlim(0.5, 5.5)
plt.ylim(0.5, 5.5)
plt.xlabel("Valence (1 = very unpleasant, 5 = very pleasant)")
plt.ylabel("Arousal (1 = very low, 5 = very high)")
plt.title("Self-reported valence and arousal (jittered), coloured by word")
plt.legend(bbox_to_anchor=(1.02, 1), loc="upper left", fontsize=8)
plt.tight_layout()
save_fig(fig, "rq1_valence_arousal_scatter")
plt.show()

grid = pd.crosstab(df["arousal"], df["valence"]).reindex(index=[1, 2, 3, 4, 5], columns=[1, 2, 3, 4, 5], fill_value=0)
grid.to_csv(out_dir / "rq1_valence_by_arousal_rating_counts.csv", encoding="utf-8")

fig = plt.figure(figsize=(5.2, 4.4))
sns.heatmap(grid.sort_index(ascending=False), annot=True, fmt="d", cmap="Blues", cbar_kws={"label": "Number of recordings"})
plt.xlabel("Valence (1 = very unpleasant, 5 = very pleasant)")
plt.ylabel("Arousal (1 = very low, 5 = very high)")
plt.title("Recordings per valence-arousal rating")
plt.tight_layout()
save_fig(fig, "rq1_valence_arousal_counts")
plt.show()
