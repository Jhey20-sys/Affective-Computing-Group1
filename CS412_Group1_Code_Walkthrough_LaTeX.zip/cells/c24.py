X_centred = (feat_df - feat_df.groupby(df["word"].values).transform("mean")).values
rows = []
for target in TARGETS:
    y = df[target].values
    p = cross_val_predict(make_model("LogReg"), X_centred, y, cv=folds)
    base = cross_val_predict(DummyClassifier(strategy="most_frequent"), np.zeros((len(y), 1)), y, cv=folds)
    original = results[target].query("features == 'Audio: handcrafted' and model == 'LogReg'").iloc[0]["macro_f1"]
    rows.append({"target": target,
                 "uncentred handcrafted LogReg macro-F1": original,
                 "word-centred macro-F1": round(f1_score(y, p, average="macro"), 3),
                 "baseline macro-F1": round(f1_score(y, base, average="macro"), 3),
                 "word-centred accuracy": round(accuracy_score(y, p), 3),
                 "baseline accuracy": round(accuracy_score(y, base), 3)})
lex_results = pd.DataFrame(rows)
lex_results.to_csv(out_dir / "lexically_controlled_results.csv", index=False)
lex_results
