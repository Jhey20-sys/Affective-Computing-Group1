# spectrograms of the first 8 recordings (Figure 1 in the report)
# set show_word = "Kapoy" to compare only one word instead
n_show = 8
show_word = None

show = df.index.tolist() if show_word is None else df[df["word"] == show_word].sort_values("valence").index.tolist()
show = show[:n_show]

ncols = 4
nrows = math.ceil(len(show) / ncols)
fig, axes = plt.subplots(nrows, ncols, figsize=(4.4 * ncols, 3.5 * nrows), squeeze=False, constrained_layout=True)
for a in axes.ravel():
    a.set_visible(False)
for a, i in zip(axes.ravel(), show):
    a.set_visible(True)
    r = df.loc[i]
    img = plot_spectrogram(a, clips[i], f"{r['word']} | V={r['valence']} A={r['arousal']}")
fig.colorbar(img, ax=axes.ravel().tolist(), shrink=0.85, pad=0.02,
             label="Power (dB, relative to each clip's peak)", format="%+.0f dB")
fig.suptitle("Mel-spectrograms of example recordings (V = valence, A = arousal)", fontsize=12)
save_fig(fig, "spectrogram_examples" if show_word is None else f"spectrogram_examples_{show_word.lower()}")
plt.show()

# one labelled spectrogram per recording
for i, r in df.iterrows():
    name = r["file"].replace(".wav", "")
    fig, a = plt.subplots(figsize=(6.5, 4.2), constrained_layout=True)
    img = plot_spectrogram(a, clips[i], f"{r['word']} | V={r['valence']} A={r['arousal']}\n{name}")
    fig.colorbar(img, ax=a, label="Power (dB, relative to clip's peak)", format="%+.0f dB")
    fig.savefig(spec_labelled_dir / f"{name}.png", dpi=200, bbox_inches="tight")
    plt.close(fig)
print("saved", len(df), "labelled spectrograms")
