def top_model(target):
    r = results[target]
    return r[r["model"] != "Baseline"].iloc[0]


best_cfg = {}
pred_rows = []
fig, ax = plt.subplots(2, 1, figsize=(5.5, 9))
for a, target in zip(ax, TARGETS):
    y = df[target].values
    labels = sorted(set(y))
    best = top_model(target)
    k = int(best["cfg_id"])
    best_cfg[target] = configs[k]
    p = preds[(target, k)]

    sns.heatmap(confusion_matrix(y, p, labels=labels), annot=True, fmt="d", cmap="Blues",
                xticklabels=labels, yticklabels=labels, ax=a, cbar=False)
    a.set_title(f"{target}\n{best['features']} ({best['model']})", fontsize=10)
    a.set_xlabel("Predicted")
    a.set_ylabel("Self-reported")
    print(f"\n{target} - {best['features']} ({best['model']})")
    print(classification_report(y, p, zero_division=0))

    for i in range(len(y)):
        pred_rows.append({"target": target, "file": df.loc[i, "file"], "word": df.loc[i, "word"],
                          "self_reported": y[i], "predicted": p[i], "correct": y[i] == p[i]})
plt.tight_layout()
save_fig(fig, "confusion_matrices")
plt.show()

pred_df = pd.DataFrame(pred_rows)
pred_df.to_csv(out_dir / "best_model_predictions.csv", index=False, encoding="utf-8")
print("wrong predictions per word:")
pred_df["wrong"] = ~pred_df["correct"]
display(pred_df.pivot_table(index="word", columns="target", values="wrong", aggfunc="sum").fillna(0).astype(int))
