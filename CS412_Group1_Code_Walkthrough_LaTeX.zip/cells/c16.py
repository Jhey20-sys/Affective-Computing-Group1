net = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
net.fc = torch.nn.Identity()
net.eval()
to_tensor = T.Compose([T.ToTensor(), T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])

embeddings = []
with torch.no_grad():
    for p in img_paths:
        x = to_tensor(Image.open(p).convert("RGB")).unsqueeze(0)
        embeddings.append(net(x).squeeze(0).numpy())
X_cnn = np.vstack(embeddings)
print("CNN embeddings:", X_cnn.shape)
np.save(out_dir / "cnn_embeddings.npy", X_cnn)
