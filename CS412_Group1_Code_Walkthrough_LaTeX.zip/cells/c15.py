# descriptive stats for all features, then a few of them per class
desc = feat_df.describe().T.round(3)
display(desc)
desc.to_csv(out_dir / "audio_descriptive_statistics.csv", encoding="utf-8")

some_feats = ["duration", "f0_mean", "f0_std", "f0_range", "voiced_ratio", "rms_mean", "rms_max",
              "zcr_mean", "centroid_mean", "n_segments", "active_ratio", "rms_peak_pos"]
for target in ["valence_class", "arousal_class"]:
    by_class = feat_df[some_feats].groupby(df[target].values).agg(["mean", "std"]).round(3).T
    print("\n" + target)
    display(by_class)
    by_class.to_csv(out_dir / f"audio_descriptive_by_{target}.csv", encoding="utf-8")
