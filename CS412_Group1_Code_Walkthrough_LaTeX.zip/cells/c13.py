wave_dir = out_dir / "waveforms_spectrograms"
wave_dir.mkdir(parents=True, exist_ok=True)
HOP = 64      # 4 ms steps
FMAX = 8000


def plot_wave(ax, y, xlabel=True):
    t = np.arange(len(y)) / SR
    ax.plot(t, y, color="#35206B", linewidth=0.6)
    rms = librosa.feature.rms(y=y, frame_length=512, hop_length=HOP)[0]
    t_rms = librosa.times_like(rms, sr=SR, hop_length=HOP)
    ax.plot(t_rms, rms, color="#E8683A", linewidth=1.6, label="RMS energy")
    ax.plot(t_rms, -rms, color="#E8683A", linewidth=1.6)
    for s, e in librosa.effects.split(y, top_db=30):   # shade the speech parts
        ax.axvspan(s / SR, e / SR, color="#F9B95C", alpha=0.18, linewidth=0)
    ax.set_xlim(0, len(y) / SR)
    ax.set_ylim(-1.05, 1.05)
    ax.set_ylabel("Amplitude\n(peak-normalised)", fontsize=9)
    if xlabel:
        ax.set_xlabel("Time (s)", fontsize=9)
    ax.tick_params(labelsize=8)


def plot_spec_pitch(ax, y, xlabel=True, pitch=True):
    S = librosa.power_to_db(librosa.feature.melspectrogram(y=y, sr=SR, n_fft=512, hop_length=HOP, n_mels=128, fmax=FMAX), ref=np.max)
    img = librosa.display.specshow(S, sr=SR, hop_length=HOP, x_axis="time", y_axis="mel",
                                   fmax=FMAX, cmap="magma", vmin=-70, vmax=0, ax=ax)
    if pitch:
        f0, _, _ = librosa.pyin(y, fmin=65, fmax=500, sr=SR, frame_length=1024, hop_length=HOP)
        ax.plot(librosa.times_like(f0, sr=SR, hop_length=HOP), f0, color="cyan", linewidth=2, label="Pitch (f0)")
        ax.legend(loc="upper right", fontsize=8, framealpha=0.6)
    ax.grid(False)
    ax.set_xlim(0, len(y) / SR)
    ax.set_ylabel("Frequency (Hz)", fontsize=9)
    ax.set_xlabel("Time (s)" if xlabel else "", fontsize=9)
    ax.tick_params(labelsize=8)
    return img


# one figure per recording, only the first one is shown
for n, (i, r) in enumerate(df.iterrows()):
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(8, 6), sharex=True, gridspec_kw={"height_ratios": [1, 2.2]}, constrained_layout=True)
    plot_wave(a1, clips[i], xlabel=False)
    a1.legend(loc="upper right", fontsize=8)
    img = plot_spec_pitch(a2, clips[i])
    fig.colorbar(img, ax=a2, format="%+.0f dB", label="Power (dB, relative to clip's peak)")
    fig.suptitle(f"\"{r['word']}\"  |  valence {r['valence']} ({r['valence_class']}), "
                 f"arousal {r['arousal']} ({r['arousal_class']})\n{r['file'].replace('.wav', '')}", fontsize=11)
    fig.savefig(wave_dir / r["file"].replace(".wav", ".png"), dpi=200, bbox_inches="tight")
    if n == 0:
        plt.show()
    else:
        plt.close(fig)
print("saved", len(df), "waveform figures")

# one gallery per word, same time axis in every row
for word, g in df.groupby("word"):
    g = g.sort_values(["valence", "arousal"])
    longest = max(len(clips[i]) for i in g.index) / SR
    fig, axes = plt.subplots(len(g), 2, figsize=(13, 2.1 * len(g) + 0.8), squeeze=False,
                             gridspec_kw={"width_ratios": [1, 1.25]}, constrained_layout=True)
    for row, (i, r) in enumerate(g.iterrows()):
        last = row == len(g) - 1
        plot_wave(axes[row, 0], clips[i], xlabel=last)
        img = plot_spec_pitch(axes[row, 1], clips[i], xlabel=last)
        axes[row, 0].set_xlim(0, longest)
        axes[row, 1].set_xlim(0, longest)
        axes[row, 1].get_legend().remove()
        axes[row, 0].set_title(f"{r['participant']}  |  V={r['valence']}  A={r['arousal']}", fontsize=9, loc="left")
    fig.colorbar(img, ax=axes[:, 1].tolist(), format="%+.0f dB", shrink=0.6, label="dB re. clip peak")
    fig.suptitle(f"\"{word}\" – {len(g)} recording(s), sorted by valence (cyan line = pitch, shaded = speech)", fontsize=12)
    fig.savefig(out_dir / f"word_gallery_{word.lower()}.png", dpi=200, bbox_inches="tight")
    plt.close(fig)
print("saved the word galleries")
