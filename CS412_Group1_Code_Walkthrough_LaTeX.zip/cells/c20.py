sig = []
for target in TARGETS:
    y = df[target].values
    best = top_model(target)
    p = preds[(target, int(best["cfg_id"]))]
    n, correct = len(y), int((p == y).sum())
    baseline = results[target].query("model == 'Baseline'").iloc[0]["accuracy"]
    test = binomtest(correct, n, p=baseline, alternative="greater")
    ci = binomtest(correct, n).proportion_ci(confidence_level=0.95, method="wilson")
    sig.append({"target": target, "best": f"{best['features']} ({best['model']})",
                "correct": f"{correct}/{n}", "accuracy": round(correct / n, 3),
                "wilson_95_low": round(ci.low, 3), "wilson_95_high": round(ci.high, 3),
                "baseline_accuracy": baseline, "baseline_inside_CI": ci.low <= baseline <= ci.high,
                "binomial_p_one_sided": round(test.pvalue, 3)})
sig = pd.DataFrame(sig)
sig.to_csv(out_dir / "accuracy_significance.csv", index=False)
display(sig)
