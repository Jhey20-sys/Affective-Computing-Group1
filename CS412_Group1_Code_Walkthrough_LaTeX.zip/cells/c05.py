activities = ["Lecture/Discussion", "Laboratory Activity", "Programming/Coding Activity", "Quiz", "Examination",
              "Presentation/Reporting", "Group Activity", "Recitation", "Project/Practical Activity", "Other"]
years = {"Y1": "1st Year", "Y2": "2nd Year", "Y3": "3rd Year", "Y4": "4th Year"}
sessions = {"AM": "Morning", "PM": "Afternoon-Evening"}
name_pattern = re.compile(r"^(Y[1-4])-(\d{3})_(Y[1-4])_(AM|PM)_([A-Za-z]+)\.wav$")

problems = []
for _, r in df.iterrows():
    m = name_pattern.match(r["file"])
    if m is None:
        problems.append((r["file"], "filename doesn't follow Code_Year_Session_Word.wav"))
        continue
    code_year, _, year, ses, word = m.groups()
    if word not in WORDS:
        problems.append((r["file"], f"{word} is not in our word list"))
    if code_year != year:
        problems.append((r["file"], "year in code and filename don't match"))
    if years[year] != GROUP_YEAR:
        problems.append((r["file"], f"not {GROUP_YEAR}"))
    if r["Year Level"] != years[year]:
        problems.append((r["file"], "Year Level column doesn't match filename"))
    if r["Session"] != sessions[ses]:
        problems.append((r["file"], "Session column doesn't match AM/PM"))
    if r["Spoken Word"] != word:
        problems.append((r["file"], "Spoken Word column doesn't match filename"))
    if r["Class Activity"] not in activities:
        problems.append((r["file"], f"unknown activity: {r['Class Activity']}"))
    for col in ["valence", "arousal"]:
        if r[col] not in [1, 2, 3, 4, 5]:
            problems.append((r["file"], f"{col} should be 1-5, got {r[col]}"))

repeated = df["participant"][df["participant"].duplicated()].unique().tolist()
if repeated:
    problems.append(("(several)", f"participants with more than one recording: {repeated}"))

numbers = sorted(int(p.split("-")[1]) for p in df["participant"])
gaps = [n for n in range(1, max(numbers) + 1) if n not in numbers]

print(f"valid observations: {len(df)} (need {MIN_VALID})")
if len(df) < MIN_VALID:
    print(f"-> {MIN_VALID - len(df)} short, put this in the limitations")
if gaps:
    print("missing participant numbers:", [f"{n:03d}" for n in gaps])
    print("reason:", missing_reason)

if problems:
    problems_df = pd.DataFrame(problems, columns=["file", "issue"])
    display(problems_df)
    problems_df.to_csv(out_dir / "metadata_issues.csv", index=False, encoding="utf-8")
else:
    print("no problems with the metadata or filenames")

print("session cutoff:", session_cutoff)
if session_cutoff.startswith("TO FILL IN") or missing_reason.startswith("TO FILL IN"):
    print("-> still need to fill in session_cutoff / missing_reason in the setup cell")
