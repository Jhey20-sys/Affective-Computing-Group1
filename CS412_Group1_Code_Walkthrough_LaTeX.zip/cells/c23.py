lex_feats = ["f0_mean", "f0_std", "rms_mean", "rms_max", "zcr_mean", "duration"]
lex = pd.concat([df[["word", "valence_class"]], feat_df[lex_feats]], axis=1)

per_word = lex.groupby(["word", "valence_class"]).size().unstack(fill_value=0)
display(per_word)
both = per_word[(per_word > 0).sum(axis=1) >= 2].index.tolist()
print("words with both valence classes:", both)

tables = []
for w in both:
    t = lex[lex["word"] == w].groupby("valence_class").mean(numeric_only=True).round(3)
    print("\n" + w)
    display(t)
    tables.append(t.assign(word=w).reset_index())
if tables:
    pd.concat(tables).to_csv(out_dir / "lexically_controlled_descriptives.csv", index=False)
