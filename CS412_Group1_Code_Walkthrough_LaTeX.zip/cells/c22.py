rng = np.random.default_rng(SEED)
perm = []
for target in TARGETS:
    config = best_cfg[target]
    y = df[target].values
    observed = top_model(target)["macro_f1"]
    baseline_f1 = results[target].query("model == 'Baseline'").iloc[0]["macro_f1"]

    shuffled_scores = []
    for _ in range(N_PERM):
        y_shuffled = rng.permutation(y)
        shuffled_scores.append(f1_score(y_shuffled, run_lopo(config, y_shuffled), average="macro"))
    shuffled_scores = np.array(shuffled_scores)
    p_value = (np.sum(shuffled_scores >= observed) + 1) / (N_PERM + 1)

    perm.append({"target": target, "best": f"{config['features']} ({config['model']})",
                 "observed_macro_f1": observed, "baseline_macro_f1": baseline_f1,
                 "chance_mean": round(shuffled_scores.mean(), 3), "n_perm": N_PERM, "p_value": round(p_value, 3)})

    fig = plt.figure(figsize=(5, 3))
    plt.hist(shuffled_scores, bins=20, color="lightgray")
    plt.axvline(observed, color="crimson", label=f"observed = {observed}")
    plt.title(f"{target} (p = {p_value:.3f}, B = {N_PERM})", fontsize=9)
    plt.xlabel("Macro-F1, shuffled labels")
    plt.legend()
    plt.tight_layout()
    save_fig(fig, f"permutation_{target}")
    plt.show()

perm = pd.DataFrame(perm)
perm.to_csv(out_dir / "permutation_tests.csv", index=False)
perm
