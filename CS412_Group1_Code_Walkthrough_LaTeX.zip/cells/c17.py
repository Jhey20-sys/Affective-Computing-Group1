info = pd.DataFrame({
    "participant_code": df["participant"].values,
    "audio_filename": df["file"].values,
    "year_level": df["file"].map(meta_by_file["Year Level"]).values,
    "class_activity": df["file"].map(meta_by_file["Class Activity"]).values,
    "session": df["file"].map(meta_by_file["Session"]).values,
    "spoken_word": df["word"].values,
    "self_reported_feeling": df["file"].map(meta_by_file["Self-Reported Feeling"]).values,
    "valence": df["valence"].values,
    "arousal": df["arousal"].values,
    "valence_class": df["valence_class"].values,
    "arousal_class": df["arousal_class"].values,
})
audio_cols = feat_df.add_prefix("aud_").reset_index(drop=True)
dataset = pd.concat([info, audio_cols], axis=1)
dataset.to_csv(data_dir / "Group1_audio_feature_dataset.csv", index=False, encoding="utf-8")

dictionary = pd.DataFrame(
    [{"column": c, "group": "metadata (context and labels, NOT predictors)"} for c in info.columns]
    + [{"column": c, "group": "audio feature (handcrafted)"} for c in audio_cols.columns])
dictionary.to_csv(data_dir / "data_dictionary.csv", index=False, encoding="utf-8")

print("dataset:", dataset.shape)
display(dataset.iloc[:3, :14])
