final = {t: make_model("LogReg").fit(X_hand, df[t].values) for t in TARGETS}


def predict_affect(wav_path):
    x = pd.DataFrame([get_features(load_audio(wav_path))])[feat_df.columns].fillna(0.0).values
    return {t: m.predict(x)[0] for t, m in final.items()}


for t, m in final.items():
    right = int((m.predict(X_hand) == df[t].values).sum())
    print(f"{t}: {right}/30 right on its own training data (baseline {df[t].value_counts().max()}/30)")

example = audio_dir / "Y1-027_Y1_PM_Lingaw.wav"
pred = predict_affect(example)
r = df[df["file"] == example.name].iloc[0]
out = pd.DataFrame({"prediction": [pred[t] for t in TARGETS],
                    "self-reported": [r[t] for t in TARGETS],
                    "rating (1-5)": [r["valence"], r["arousal"]]}, index=TARGETS)
out["match"] = out["prediction"] == out["self-reported"]
print("\n" + example.name)
display(out)
