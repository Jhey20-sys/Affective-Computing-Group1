demo_file = "Y1-014_Y1_AM_Salamat.wav"
demo_path = audio_dir / demo_file

raw, raw_sr = librosa.load(demo_path, sr=None, mono=False)
raw_channels = 1 if raw.ndim == 1 else raw.shape[0]
raw_mono = raw if raw.ndim == 1 else raw.mean(axis=0)
y16, _ = librosa.load(demo_path, sr=SR, mono=True)          # resample + mono
y_trim, (start, end) = librosa.effects.trim(y16, top_db=25)  # cut silence at the start/end
y_norm = librosa.util.normalize(y_trim)                      # peak = 1


def step_row(name, y, sr, ch):
    return [name, f"{sr} Hz", ch, len(y), round(len(y) / sr, 3), round(float(np.abs(y).max()), 3)]


steps = pd.DataFrame([
    step_row("1. raw wav", raw_mono, raw_sr, raw_channels),
    step_row("2. 16 kHz mono", y16, SR, 1),
    step_row("3. trimmed", y_trim, SR, 1),
    step_row("4. normalised", y_norm, SR, 1),
], columns=["step", "sample rate", "channels", "samples", "duration (s)", "peak"])
print(demo_file)
display(steps)

fig, ax = plt.subplots(3, 1, figsize=(11, 7), constrained_layout=True)
ax[0].plot(np.arange(len(y16)) / SR, y16, linewidth=0.6, color="#35206B")
ax[0].axvspan(start / SR, end / SR, color="#F9B95C", alpha=0.3, label="kept after trimming")
ax[0].set_title("16 kHz mono signal (shaded part is kept)")
ax[0].legend(loc="upper right")
ax[1].plot(np.arange(len(y_norm)) / SR, y_norm, linewidth=0.6, color="#B5367A")
ax[1].set_title("trimmed and normalised")
ax[1].set_ylim(-1.05, 1.05)
S = librosa.power_to_db(librosa.feature.melspectrogram(y=y_norm, sr=SR, n_fft=1024, hop_length=128, n_mels=N_MELS), ref=np.max)
librosa.display.specshow(S, sr=SR, hop_length=128, x_axis="time", y_axis="mel", fmax=SR / 2, cmap="magma", ax=ax[2])
ax[2].set_title("mel-spectrogram")
ax[0].set_xlabel("Time (s)")
ax[1].set_xlabel("Time (s)")
plt.show()

vec = get_features(y_norm)


def feature_group(name):
    for prefix, group in [("ddmfcc", "MFCC delta-delta SD"), ("dmfcc", "MFCC delta SD"), ("mfcc", "MFCC mean/SD"),
                          ("f0", "Pitch"), ("voiced", "Pitch"), ("rms", "Energy"), ("zcr", "Zero-crossing rate"),
                          ("centroid", "Spectral centroid")]:
        if name.startswith(prefix):
            return group
    return "Timing"


vec_table = pd.DataFrame({"feature": list(vec), "value": [round(float(v), 4) for v in vec.values()]})
vec_table["group"] = vec_table["feature"].map(feature_group)
print(len(vec_table), "features")
display(vec_table.groupby("group").size().to_frame("count"))
pd.set_option("display.max_rows", 100)
display(vec_table[["group", "feature", "value"]])

vec_row = pd.DataFrame([vec])[feat_df.columns]
display(vec_row)
saved_row = feat_df.loc[df.index[df["file"] == demo_file][0]].values
print("same as the saved row:", np.allclose(vec_row.values[0], saved_row, equal_nan=True))
