quality = []
for _, r in df.iterrows():
    y, sr = librosa.load(r["path"], sr=None, mono=False)
    channels = 1 if y.ndim == 1 else y.shape[0]
    if y.ndim > 1:
        y = y.mean(axis=0)
    dur = len(y) / sr
    peak = float(np.max(np.abs(y)))
    clipped = float(np.mean(np.abs(y) >= 0.99))
    rms_db = float(20 * np.log10(np.sqrt(np.mean(y ** 2)) + 1e-9))
    active = float(sum(e - s for s, e in librosa.effects.split(y, top_db=30)) / len(y)) if len(y) else 0.0

    flags = []
    if dur < 0.3:
        flags.append("very short")
    if dur > 5:
        flags.append("long (may contain extra speech)")
    if peak < 0.05:
        flags.append("very quiet")
    if clipped > 0.001:
        flags.append("clipping")
    if active < 0.1:
        flags.append("mostly silence")

    quality.append({"file": r["file"], "sample_rate": sr, "channels": channels, "duration_s": round(dur, 2),
                    "peak": round(peak, 3), "rms_dB": round(rms_db, 1), "clipping_frac": round(clipped, 4),
                    "active_ratio": round(active, 2), "flags": "; ".join(flags)})

quality = pd.DataFrame(quality)
quality.to_csv(out_dir / "audio_quality_report.csv", index=False)
print("sample rates:", sorted(quality["sample_rate"].unique()), "| channels:", sorted(quality["channels"].unique()))
display(quality.describe().round(2))
print("flagged:", (quality["flags"] != "").sum())
display(quality[quality["flags"] != ""])
