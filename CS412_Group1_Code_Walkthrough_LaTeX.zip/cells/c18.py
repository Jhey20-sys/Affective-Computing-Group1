feature_sets = {"Audio: handcrafted": X_hand, "Audio: spectrogram CNN": X_cnn}
model_names = ["LogReg", "SVM", "RandomForest"]
TARGETS = ["valence_class", "arousal_class"]

folds = list(LeaveOneGroupOut().split(X_hand, groups=df["participant"].values))
print(len(folds), "folds")


def make_model(name):
    if name == "LogReg":
        clf = LogisticRegression(C=0.5, max_iter=2000, class_weight="balanced")
    elif name == "SVM":
        clf = SVC(kernel="rbf", C=1.0, class_weight="balanced")
    else:
        clf = RandomForestClassifier(n_estimators=100, max_depth=4, min_samples_leaf=2,
                                     class_weight="balanced", random_state=SEED)
    return make_pipeline(StandardScaler(), PCA(n_components=N_PCA, random_state=SEED), clf)


def run_lopo(config, y):
    if config["model"] == "Baseline":
        return cross_val_predict(DummyClassifier(strategy="most_frequent"), np.zeros((len(y), 1)), y, cv=folds)
    return cross_val_predict(make_model(config["model"]), feature_sets[config["features"]], y, cv=folds)


configs = [{"features": "Baseline (majority)", "model": "Baseline"}]
for fs in feature_sets:
    for m in model_names:
        configs.append({"features": fs, "model": m})

results, preds = {}, {}
for target in TARGETS:
    y = df[target].values
    rows = []
    for k, config in enumerate(configs):
        p = run_lopo(config, y)
        preds[(target, k)] = p
        rows.append({"features": config["features"], "model": config["model"],
                     "accuracy": round(accuracy_score(y, p), 3),
                     "macro_f1": round(f1_score(y, p, average="macro"), 3), "cfg_id": k})
    results[target] = pd.DataFrame(rows).sort_values("macro_f1", ascending=False).reset_index(drop=True)
    print("\n" + target)
    display(results[target].drop(columns="cfg_id"))

all_results = pd.concat([r.assign(target=t) for t, r in results.items()]).drop(columns="cfg_id")
all_results.to_csv(out_dir / "model_results.csv", index=False)
