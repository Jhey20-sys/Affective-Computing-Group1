listed = meta["Audio Filename"].astype(str).tolist()
wavs = sorted(p.name for p in audio_dir.glob("*.wav"))
mp4s = sorted(p.name for p in video_dir.glob("*.mp4")) if video_dir.exists() else []

files = pd.DataFrame({
    "participant": meta["Participant Code"],
    "audio_file": listed,
    "wav_found": [f in wavs for f in listed],
    "mp4_found": [f.replace(".wav", ".mp4") in mp4s for f in listed],
    "valence": meta["Valence"].values,
    "arousal": meta["Arousal"].values,
})
files["labels_valid"] = files["valence"].isin([1, 2, 3, 4, 5]) & files["arousal"].isin([1, 2, 3, 4, 5])
files["valence_class"] = np.where(files["valence"] > 3, "positive", "non-positive")
files["arousal_class"] = np.where(files["arousal"] > 3, "high", "low-mod")

counts = pd.Series({
    "metadata rows": len(files),
    "participants": files["participant"].nunique(),
    "wav files": len(wavs),
    "rows with a wav": int(files["wav_found"].sum()),
    "mp4 files": len(mp4s),
    "rows with an mp4": int(files["mp4_found"].sum()),
    "rows with valid labels": int(files["labels_valid"].sum()),
})
display(counts.to_frame("count"))

print("wav files not in the metadata:", sorted(set(wavs) - set(listed)) or "none")
print("mp4 files not in the metadata:", sorted(set(mp4s) - {f.replace(".wav", ".mp4") for f in listed}) or "none")

print("\nlabels:")
print(files["valence_class"].value_counts().to_dict())
print(files["arousal_class"].value_counts().to_dict())
display(files)
files.to_csv(out_dir / "file_correspondence_check.csv", index=False)
