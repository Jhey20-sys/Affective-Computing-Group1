def load_audio(path):
    y, _ = librosa.load(path, sr=SR, mono=True)
    y, _ = librosa.effects.trim(y, top_db=25)
    if len(y) < 1024:
        y = np.pad(y, (0, 1024 - len(y)))
    return librosa.util.normalize(y)


def mean_std(x, name):
    return {f"{name}_mean": float(np.mean(x)), f"{name}_std": float(np.std(x))}


def get_features(y):
    f = {"duration": len(y) / SR}

    segs = librosa.effects.split(y, top_db=30)
    f["n_segments"] = len(segs)
    f["active_ratio"] = float(sum(e - s for s, e in segs) / len(y))
    rms = librosa.feature.rms(y=y)[0]
    f["rms_peak_pos"] = float(np.argmax(rms) / max(len(rms) - 1, 1))

    f0, voiced, _ = librosa.pyin(y, fmin=65, fmax=500, sr=SR)
    f0 = f0[~np.isnan(f0)]
    if len(f0):
        f.update({"f0_mean": f0.mean(), "f0_std": f0.std(), "f0_range": f0.max() - f0.min()})
    else:
        f.update({"f0_mean": 0.0, "f0_std": 0.0, "f0_range": 0.0})
    f["voiced_ratio"] = float(np.mean(voiced))

    f.update(mean_std(rms, "rms"))
    f["rms_max"] = float(rms.max())
    f.update(mean_std(librosa.feature.zero_crossing_rate(y)[0], "zcr"))
    f.update(mean_std(librosa.feature.spectral_centroid(y=y, sr=SR)[0], "centroid"))

    mfcc = librosa.feature.mfcc(y=y, sr=SR, n_mfcc=13)
    d1 = librosa.feature.delta(mfcc, width=5, mode="nearest")
    d2 = librosa.feature.delta(mfcc, order=2, width=5, mode="nearest")
    for i in range(13):
        f.update(mean_std(mfcc[i], f"mfcc{i}"))
        f[f"dmfcc{i}_std"] = float(np.std(d1[i]))
        f[f"ddmfcc{i}_std"] = float(np.std(d2[i]))
    return f


def pad_or_cut(y):
    n = int(CLIP_SEC * SR)
    return y[:n] if len(y) >= n else np.pad(y, (0, n - len(y)))


def mel_db(y):
    S = librosa.feature.melspectrogram(y=pad_or_cut(y), sr=SR, n_fft=1024, hop_length=128, n_mels=N_MELS)
    return librosa.power_to_db(S, ref=np.max)


def save_spectrogram_image(y, path):
    # no axes, this is what the CNN sees
    S = mel_db(y)
    S = (S - S.min()) / (S.max() - S.min() + 1e-9)
    rgb = (matplotlib.colormaps["magma"](S)[..., :3] * 255).astype(np.uint8)
    Image.fromarray(np.flipud(rgb)).resize((IMG_SIZE, IMG_SIZE), Image.BILINEAR).save(path)
    return str(path)


def plot_spectrogram(ax, y, title):
    img = librosa.display.specshow(mel_db(y), sr=SR, hop_length=128, x_axis="time", y_axis="mel",
                                   fmax=SR / 2, cmap="magma", vmin=-80, vmax=0, ax=ax)
    ax.set_title(title, fontsize=10)
    ax.set_xlabel("Time (s)", fontsize=9)
    ax.set_ylabel("Frequency (Hz)", fontsize=9)
    ax.tick_params(labelsize=8)
    return img


rows, img_paths, clips = [], [], {}
for i, r in df.iterrows():
    y = load_audio(r["path"])
    clips[i] = y
    rows.append(get_features(y))
    img_paths.append(save_spectrogram_image(y, spec_dir / r["file"].replace(".wav", ".png")))

feat_df = pd.DataFrame(rows).fillna(0.0)
X_hand = feat_df.values
print("features:", X_hand.shape)
feat_df.assign(file=df["file"]).to_csv(out_dir / "acoustic_features.csv", index=False)
